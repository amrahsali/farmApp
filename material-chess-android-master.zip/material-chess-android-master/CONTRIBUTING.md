#How to contribute

1. Open up Android Studio

2. Select new project from Version Control

3. Add the github repo link for this project

4. Make a branch and get started on the issues, or make your own if you find bugs. Do not send pull requests from master.
